AFINTY — actualización de Hospital y médicos

Incluye:
- 3 fotos proporcionadas del Hospital Nacional Arzobispo Loayza:
  assets/hospital-fachada.png
  assets/hospital-jardines.png
  assets/hospital-mapa.png
- Sección de ubicación con dirección y botón para abrir Google Maps.
- Galería del hospital.
- Tarjetas de médicos con:
  nombre, especialidad, área y explicación "¿En qué puede ayudarte?"
- Soporte para fotos reales de médicos mediante FOTO_DOCTOR_POR_ID.

IMPORTANTE:
No se asignaron fotos de personas a médicos específicos porque las imágenes proporcionadas no identifican de forma verificable a esos profesionales. Para agregar fotos reales, coloca imágenes autorizadas en assets/doctores/ y completa FOTO_DOCTOR_POR_ID, por ejemplo:
  1: "./assets/doctores/1.jpg"

Referencia de diseño:
La estructura toma como referencia el patrón público de búsqueda de proveedores de Cleveland Clinic (búsqueda por nombre/especialidad/ubicación y perfiles resumidos), sin copiar su contenido.
